import { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { QuizResult } from '@/types/quiz';
import { quizzes } from '@/data/quizzes';
import { Trophy, CircleCheck as CheckCircle2, Circle as XCircle } from 'lucide-react-native';

export default function ResultsScreen() {
  const [results, setResults] = useState<QuizResult[]>([]);

  useEffect(() => {
    const storedResults = JSON.parse(localStorage.getItem('quizResults') || '[]');
    setResults(storedResults);
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Trophy size={28} color="#6366f1" />
        <Text style={styles.title}>Your Results</Text>
      </View>

      <ScrollView style={styles.resultsList}>
        {results.length === 0 ? (
          <View style={styles.emptyState}>
            <Trophy size={64} color="#94a3b8" />
            <Text style={styles.emptyStateTitle}>No Results Yet</Text>
            <Text style={styles.emptyStateText}>
              Complete a quiz to see your results here
            </Text>
          </View>
        ) : (
          results.map((result, index) => {
            const quiz = quizzes.find((q) => q.id === result.quizId);
            const percentage = (result.correctAnswers / result.totalQuestions) * 100;
            const incorrectAnswers = result.totalQuestions - result.correctAnswers;
            const date = new Date(result.date).toLocaleDateString();

            return (
              <View key={index} style={styles.resultCard}>
                <View style={styles.resultHeader}>
                  <Text style={styles.quizTitle}>{quiz?.title}</Text>
                  <Text style={styles.date}>{date}</Text>
                </View>

                <View style={styles.scoreContainer}>
                  <View style={[styles.scoreCircle, { backgroundColor: getScoreColor(percentage) }]}>
                    <Text style={styles.scorePercentage}>{percentage.toFixed(0)}%</Text>
                  </View>
                </View>

                <View style={styles.statsContainer}>
                  <View style={styles.statItem}>
                    <CheckCircle2 size={20} color="#059669" />
                    <View>
                      <Text style={styles.statLabel}>Correct</Text>
                      <Text style={[styles.statValue, styles.correctText]}>
                        {result.correctAnswers} questions
                      </Text>
                    </View>
                  </View>

                  <View style={styles.statDivider} />

                  <View style={styles.statItem}>
                    <XCircle size={20} color="#dc2626" />
                    <View>
                      <Text style={styles.statLabel}>Incorrect</Text>
                      <Text style={[styles.statValue, styles.incorrectText]}>
                        {incorrectAnswers} questions
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
            );
          })
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

function getScoreColor(percentage: number): string {
  if (percentage >= 80) return '#059669';
  if (percentage >= 60) return '#0891b2';
  if (percentage >= 40) return '#d97706';
  return '#dc2626';
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 20,
    paddingTop: 24,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1e293b',
  },
  resultsList: {
    padding: 20,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
    gap: 12,
  },
  emptyStateTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1e293b',
    marginTop: 8,
  },
  emptyStateText: {
    fontSize: 16,
    color: '#64748b',
    textAlign: 'center',
  },
  resultCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  resultHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  quizTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1e293b',
  },
  date: {
    fontSize: 14,
    color: '#64748b',
  },
  scoreContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  scoreCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scorePercentage: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    borderRadius: 12,
    padding: 16,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  statDivider: {
    width: 1,
    height: 40,
    backgroundColor: '#e2e8f0',
  },
  statLabel: {
    fontSize: 14,
    color: '#64748b',
  },
  statValue: {
    fontSize: 16,
    fontWeight: '600',
  },
  correctText: {
    color: '#059669',
  },
  incorrectText: {
    color: '#dc2626',
  },
});