import { View, Text, StyleSheet, Image, Pressable, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { quizzes } from '@/data/quizzes';
import { Brain } from 'lucide-react-native';

export default function QuizListScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Brain size={28} color="#6366f1" />
          <Text style={styles.title}>Available Quizzes</Text>
        </View>
        
        <View style={styles.quizList}>
          {quizzes.map((quiz) => (
            <Pressable
              key={quiz.id}
              style={styles.quizCard}
              onPress={() => router.push(`/quiz/${quiz.id}`)}
            >
              <Image source={{ uri: quiz.image }} style={styles.quizImage} />
              <View style={styles.quizContent}>
                <View style={styles.quizInfo}>
                  <Text style={styles.quizTitle}>{quiz.title}</Text>
                  <Text style={styles.quizDescription}>{quiz.description}</Text>
                  <View style={styles.quizBadge}>
                    <Text style={styles.quizBadgeText}>{quiz.questions.length} Questions</Text>
                  </View>
                </View>
              </View>
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  content: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 20,
    paddingTop: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1e293b',
  },
  quizList: {
    padding: 20,
    paddingTop: 8,
    gap: 20,
  },
  quizCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  quizImage: {
    width: '100%',
    height: 180,
  },
  quizContent: {
    padding: 16,
  },
  quizInfo: {
    gap: 8,
  },
  quizTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1e293b',
  },
  quizDescription: {
    fontSize: 14,
    color: '#64748b',
  },
  quizBadge: {
    alignSelf: 'flex-start',
    backgroundColor: '#f1f5f9',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    marginTop: 4,
  },
  quizBadgeText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#6366f1',
  },
});