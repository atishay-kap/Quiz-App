import { useState } from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { quizzes } from '@/data/quizzes';
import { Option } from '@/types/quiz';
import { Check, X } from 'lucide-react-native';

export default function QuizScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const quiz = quizzes.find((q) => q.id === id);

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<Option | null>(null);
  const [isAnswerChecked, setIsAnswerChecked] = useState(false);
  const [correctAnswers, setCorrectAnswers] = useState(0);

  if (!quiz) {
    return (
      <SafeAreaView style={styles.container}>
        <Text>Quiz not found</Text>
      </SafeAreaView>
    );
  }

  const currentQuestion = quiz.questions[currentQuestionIndex];

  const handleOptionSelect = (option: Option) => {
    if (!isAnswerChecked) {
      setSelectedOption(option);
    }
  };

  const handleCheckAnswer = () => {
    if (selectedOption?.isCorrect) {
      setCorrectAnswers((prev) => prev + 1);
    }
    setIsAnswerChecked(true);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswerChecked(false);
    } else {
      // Save result and navigate to results screen
      const result = {
        quizId: quiz.id,
        correctAnswers,
        totalQuestions: quiz.questions.length,
        date: new Date().toISOString(),
      };
      
      // Get existing results from storage or initialize empty array
      const existingResults = JSON.parse(localStorage.getItem('quizResults') || '[]');
      localStorage.setItem('quizResults', JSON.stringify([...existingResults, result]));
      
      router.replace('/results');
    }
  };

  const getOptionStyle = (option: Option) => {
    if (!isAnswerChecked) {
      return option.id === selectedOption?.id
        ? styles.selectedOption
        : styles.option;
    }

    if (option.isCorrect) {
      return styles.correctOption;
    }

    if (option.id === selectedOption?.id && !option.isCorrect) {
      return styles.incorrectOption;
    }

    return styles.option;
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.progress}>
          Question {currentQuestionIndex + 1} of {quiz.questions.length}
        </Text>
        <Text style={styles.quizTitle}>{quiz.title}</Text>
      </View>

      <View style={styles.questionContainer}>
        <Text style={styles.questionText}>{currentQuestion.text}</Text>

        <View style={styles.optionsContainer}>
          {currentQuestion.options.map((option) => (
            <Pressable
              key={option.id}
              style={[styles.optionButton, getOptionStyle(option)]}
              onPress={() => handleOptionSelect(option)}
              disabled={isAnswerChecked}
            >
              <Text
                style={[
                  styles.optionText,
                  isAnswerChecked && option.isCorrect && styles.correctOptionText,
                  isAnswerChecked &&
                    option.id === selectedOption?.id &&
                    !option.isCorrect &&
                    styles.incorrectOptionText,
                ]}
              >
                {option.text}
              </Text>
              {isAnswerChecked && option.isCorrect && (
                <Check color="#059669" size={20} />
              )}
              {isAnswerChecked && option.id === selectedOption?.id && !option.isCorrect && (
                <X color="#dc2626" size={20} />
              )}
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.footer}>
        {!isAnswerChecked ? (
          <Pressable
            style={[
              styles.button,
              !selectedOption && styles.buttonDisabled,
            ]}
            disabled={!selectedOption}
            onPress={handleCheckAnswer}
          >
            <Text style={styles.buttonText}>Check Answer</Text>
          </Pressable>
        ) : (
          <Pressable
            style={[styles.button, styles.nextButton]}
            onPress={handleNextQuestion}
          >
            <Text style={styles.buttonText}>
              {currentQuestionIndex === quiz.questions.length - 1
                ? 'Finish Quiz'
                : 'Next Question'}
            </Text>
          </Pressable>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  progress: {
    fontSize: 14,
    color: '#6366f1',
    fontWeight: '500',
  },
  quizTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1e293b',
    marginTop: 4,
  },
  questionContainer: {
    flex: 1,
    padding: 20,
  },
  questionText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 24,
  },
  optionsContainer: {
    gap: 12,
  },
  optionButton: {
    padding: 16,
    borderRadius: 12,
    backgroundColor: '#fff',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  option: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  selectedOption: {
    backgroundColor: '#fff',
    borderWidth: 2,
    borderColor: '#6366f1',
  },
  correctOption: {
    backgroundColor: '#f0fdf4',
    borderWidth: 1,
    borderColor: '#059669',
  },
  incorrectOption: {
    backgroundColor: '#fef2f2',
    borderWidth: 1,
    borderColor: '#dc2626',
  },
  optionText: {
    fontSize: 16,
    color: '#1e293b',
  },
  correctOptionText: {
    color: '#059669',
  },
  incorrectOptionText: {
    color: '#dc2626',
  },
  footer: {
    padding: 20,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  button: {
    backgroundColor: '#6366f1',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  buttonDisabled: {
    backgroundColor: '#cbd5e1',
  },
  nextButton: {
    backgroundColor: '#059669',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});